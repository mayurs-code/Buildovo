package com.InfinitySolutions.buildovo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    LocationManager locationManager;
    LocationListener locationListener;
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
        {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED)
            {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,10000,100, locationListener);


            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        {
            BottomNavigationView navigationView =(BottomNavigationView) findViewById(R.id.navigationView);;

        }//bottom navigation bar
        {
            locationManager =(LocationManager)this.getSystemService(Context.LOCATION_SERVICE);
            locationListener =new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {

                    Geocoder geocoder=new Geocoder(getApplicationContext(), Locale.ENGLISH);
                    try {
                        List<Address> listAddress=geocoder.getFromLocation(location.getLatitude(),location.getLongitude(),1);
                        if(listAddress!=null && listAddress.size()>0)

                        {
                            TextView location_header =(TextView)findViewById(R.id.location_text_view);
                            String address="";
                            Log.i("Address PROJECT",listAddress.get(0).toString());
                            address=listAddress.get(0).getAddressLine(0);
                            location_header.setText(address.substring(0,address.indexOf(',')));
                            Log.i("Address PROJECT",address.substring(0,address.indexOf(',')));
                        }
                    }
                    catch (Exception e)
                    {

                    }





                }

                @Override
                public void onStatusChanged(String s, int i, Bundle bundle) {

                }

                @Override
                public void onProviderEnabled(String s) {

                }

                @Override
                public void onProviderDisabled(String s) {

                }
            };
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED)
            {

                ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
            }
            else
            {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,0, locationListener);
            }
        }//loction Service
    }

    public void create_advertize_button(View view)
    {
        ImageButton sample_button =(ImageButton)findViewById(R.id.ad_button_first);
        LinearLayout advertize_layout=(LinearLayout)findViewById(R.id.advertize_linear_layout);
        ImageButton new_button=new ImageButton(this);
        new_button.setLayoutParams(sample_button.getLayoutParams());
        advertize_layout.addView(new_button,0);
    }
}
